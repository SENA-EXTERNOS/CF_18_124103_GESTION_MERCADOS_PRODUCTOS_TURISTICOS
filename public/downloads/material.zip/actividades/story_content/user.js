function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6UUkxYrAp7D":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

